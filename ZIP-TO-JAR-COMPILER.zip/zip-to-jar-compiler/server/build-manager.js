const fs = require("fs").promises;
const path = require("path");
const { spawn } = require("child_process");

function commandFor(projectRoot, project) {
  if (project.type === "gradle") {
    const wrapper = process.platform === "win32" ? "gradlew.bat" : "./gradlew";
    if (project.wrapper) return { cmd: process.platform === "win32" ? "gradlew.bat" : "./gradlew", args: ["build", "--no-daemon"] };
    return { cmd: process.platform === "win32" ? "gradle.bat" : "gradle", args: ["build", "--no-daemon"] };
  }
  return { cmd: process.platform === "win32" ? "mvn.cmd" : "mvn", args: ["package", "-DskipTests"] };
}

function runCommand(cmd, args, cwd, timeoutMs, onLog) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd, shell: false, windowsHide: true,
      env: { ...process.env, CI: "true", GRADLE_OPTS: `${process.env.GRADLE_OPTS || ""} -Dorg.gradle.daemon=false` }
    });
    let buffer = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      const e = new Error("Build timed out. The project exceeded the configured build time limit.");
      e.publicMessage = e.message; reject(e);
    }, timeoutMs);
    const consume = chunk => {
      buffer += chunk.toString();
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";
      for (const line of lines) if (line.trim()) onLog(line.slice(0, 4000));
    };
    child.stdout.on("data", consume);
    child.stderr.on("data", consume);
    child.on("error", e => { clearTimeout(timer); e.publicMessage = `Could not start build tool: ${e.message}. Check that the required JDK and Gradle/Maven tooling are installed.`; reject(e); });
    child.on("close", code => {
      clearTimeout(timer);
      if (buffer.trim()) onLog(buffer.slice(0, 4000));
      if (code === 0) resolve(); else {
        const e = new Error(`Build command failed with exit code ${code}.`);
        e.publicMessage = `${e.message} Review the compiler/build output below.`;
        reject(e);
      }
    });
  });
}

async function findJars(root) {
  const dirs = [path.join(root, "build", "libs"), path.join(root, "target")];
  const found = [];
  async function scan(dir) {
    try {
      for (const e of await require("fs").promises.readdir(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isFile() && e.name.toLowerCase().endsWith(".jar") && !/(?:-sources|-javadoc)\\.jar$/i.test(e.name)) {
          const st = await require("fs").promises.stat(p);
          if (st.size > 100) found.push({ p, size: st.size });
        }
      }
    } catch {}
  }
  for (const d of dirs) await scan(d);
  return found.sort((a,b) => b.size - a.size);
}

async function isJar(pathname) {
  const fh = await require("fs").promises.open(pathname, "r");
  try {
    const b = Buffer.alloc(4); await fh.read(b, 0, 4, 0);
    return b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
  } finally { await fh.close(); }
}

async function runBuild({ projectRoot, project, timeoutMs, onLog, onPhase }) {
  const command = commandFor(projectRoot, project);
  if (project.type === "gradle") onLog(`Running: ${command.cmd} ${command.args.join(" ")}`);
  else onLog(`Running: ${command.cmd} ${command.args.join(" ")}`);
  onPhase("deps");
  await runCommand(command.cmd, command.args, projectRoot, timeoutMs, onLog);
  onPhase("compile"); onPhase("jar");
  const jars = await findJars(projectRoot);
  for (const j of jars) {
    if (await isJar(j.p)) return { jarPath: j.p };
  }
  return { jarPath: null };
}

module.exports = { runBuild };