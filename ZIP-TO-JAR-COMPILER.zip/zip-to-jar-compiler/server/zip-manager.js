const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");
const { inside } = require("./security");

function runPython(args, cwd, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.env.PYTHON || "python3", args, { cwd, windowsHide: true });
    let out = "", err = "";
    const timer = setTimeout(() => { p.kill("SIGKILL"); reject(new Error("ZIP extraction timed out.")); }, timeoutMs);
    p.stdout.on("data", d => out += d);
    p.stderr.on("data", d => err += d);
    p.on("error", e => { clearTimeout(timer); reject(e); });
    p.on("close", code => {
      clearTimeout(timer);
      code === 0 ? resolve(out) : reject(new Error(err.trim() || `ZIP extractor exited with ${code}.`));
    });
  });
}

async function extractZipSafely(zipPath, dest, maxBytes) {
  // Python stdlib is used only as a safe archive parser/extractor; it never runs files from the archive.
  const script = `
import sys, zipfile, os, posixpath
zpath, dest, max_bytes = sys.argv[1], sys.argv[2], int(sys.argv[3])
total = 0
with zipfile.ZipFile(zpath) as z:
    bad = z.testzip()
    if bad:
        raise RuntimeError("ZIP integrity check failed.")
    for info in z.infolist():
        name = info.filename.replace("\\\\", "/")
        if name.startswith("/") or name.startswith("\\\\") or ":" in name.split("/")[0]:
            raise RuntimeError("ZIP contains an unsafe absolute path.")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            raise RuntimeError("ZIP path traversal detected.")
        if info.is_dir(): continue
        total += info.file_size
        if total > max_bytes:
            raise RuntimeError("ZIP expands beyond the configured extraction limit.")
        target = os.path.realpath(os.path.join(dest, *parts))
        root = os.path.realpath(dest) + os.sep
        if not target.startswith(root):
            raise RuntimeError("ZIP extraction path escaped the build directory.")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with z.open(info) as src, open(target, "wb") as dst:
            while True:
                b = src.read(1024*1024)
                if not b: break
                dst.write(b)
print("ok")
`;
  const tmp = path.join(dest, `.extract-${crypto.randomBytes(8).toString("hex")}.py`);
  await fsp.writeFile(tmp, script, "utf8");
  try {
    await runPython([tmp, zipPath, dest, String(maxBytes)], dest);
  } finally { await fsp.rm(tmp, { force: true }); }

  // Detect a single top-level project folder and use it when appropriate.
  const entries = (await fsp.readdir(dest, { withFileTypes: true })).filter(e => !e.name.startsWith(".extract-"));
  if (entries.length === 1 && entries[0].isDirectory()) {
    const nested = path.join(dest, entries[0].name);
    if ((await fsp.readdir(nested)).length) return nested;
  }
  return dest;
}

async function cleanupDir(dir) {
  try { await fsp.rm(dir, { recursive: true, force: true }); } catch {}
}

module.exports = { extractZipSafely, cleanupDir };