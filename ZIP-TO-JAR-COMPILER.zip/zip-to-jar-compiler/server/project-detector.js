const fs = require("fs").promises;
const path = require("path");

async function exists(p) { try { await fs.access(p); return true; } catch { return false; } }

async function walk(root, depth = 3, out = []) {
  if (depth < 0) return out;
  for (const e of await fs.readdir(root, { withFileTypes: true })) {
    if ([".git", ".gradle", "node_modules", "build", "target"].includes(e.name)) continue;
    const p = path.join(root, e.name);
    if (e.isDirectory()) await walk(p, depth - 1, out);
    else out.push(p);
  }
  return out;
}

function parseMinecraft(text, file) {
  const result = {};
  const loader = file.includes("fabric") ? "Fabric" : file.includes("neoforge") ? "NeoForge" : file.includes("mods.toml") ? "Forge" : null;
  if (loader) result.loader = loader;
  const versionPatterns = [
    /minecraft(?:Version|_version|VersionName)?\\s*[=:]\\s*["']?([0-9]+(?:\\.[0-9]+){1,3})/i,
    /minecraft_version\\s*=\\s*["']([^"']+)/i
  ];
  for (const r of versionPatterns) { const m = text.match(r); if (m) { result.version = m[1]; break; } }
  return result;
}

async function detectProject(root) {
  const files = await walk(root);
  const names = new Set(files.map(f => path.relative(root, f).replaceAll("\\", "/")));
  const hasGradle = [...names].some(n => ["build.gradle", "build.gradle.kts"].includes(path.basename(n)));
  const hasMaven = [...names].some(n => path.basename(n) === "pom.xml");
  if (!hasGradle && !hasMaven) return null;

  const gradleRoot = hasGradle ? root : null;
  const wrapper = gradleRoot && await exists(path.join(gradleRoot, "gradlew"));
  const buildFiles = files.filter(f => /(^|\/)(build.gradle|build.gradle.kts|settings.gradle|settings.gradle.kts|pom.xml|fabric.mod.json|mods.toml|neoforge.mods.toml)$/.test(path.relative(root, f).replaceAll("\\", "/")));
  let minecraft = {};
  for (const f of buildFiles) {
    const base = path.basename(f);
    if (["build.gradle","build.gradle.kts","settings.gradle","settings.gradle.kts","pom.xml"].includes(base) || base.endsWith(".toml") || base === "fabric.mod.json") {
      const text = await fs.readFile(f, "utf8").catch(() => "");
      minecraft = { ...minecraft, ...parseMinecraft(text, base) };
    }
  }
  return { type: hasGradle ? "gradle" : "maven", root, wrapper: !!wrapper, minecraft };
}

module.exports = { detectProject };