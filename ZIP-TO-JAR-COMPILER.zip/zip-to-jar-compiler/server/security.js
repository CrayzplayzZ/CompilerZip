const path = require("path");

function isValidBuildId(id) {
  return typeof id === "string" && /^[a-f0-9]{32}$/.test(id);
}

function safeJarName(name) {
  const base = path.basename(name).replace(/[^a-zA-Z0-9._-]/g, "_");
  return base.toLowerCase().endsWith(".jar") ? base : `${base}.jar`;
}

function inside(parent, target) {
  const p = path.resolve(parent) + path.sep;
  return path.resolve(target).startsWith(p);
}

module.exports = { isValidBuildId, safeJarName, inside };