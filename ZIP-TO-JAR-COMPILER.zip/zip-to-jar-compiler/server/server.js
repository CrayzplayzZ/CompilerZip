const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const fsp = fs.promises;
const crypto = require("crypto");
const { detectProject } = require("./project-detector");
const { extractZipSafely, cleanupDir } = require("./zip-manager");
const { runBuild } = require("./build-manager");
const { isValidBuildId, safeJarName } = require("./security");

const ROOT = path.resolve(__dirname, "..");
const UPLOADS = path.join(ROOT, "uploads");
const BUILDS = path.join(ROOT, "builds");
const PUBLIC = path.join(ROOT, "public");

const MAX_UPLOAD = Number(process.env.MAX_UPLOAD_BYTES || 250 * 1024 * 1024);
const MAX_EXTRACTED = Number(process.env.MAX_EXTRACTED_BYTES || 1024 * 1024 * 1024);
const BUILD_TIMEOUT = Number(process.env.BUILD_TIMEOUT_MS || 15 * 60 * 1000);
const PORT = Number(process.env.PORT || 3000);

for (const dir of [UPLOADS, BUILDS]) fs.mkdirSync(dir, { recursive: true });

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));
app.use(express.static(PUBLIC, { extensions: ["html"] }));

const upload = multer({
  dest: UPLOADS,
  limits: { fileSize: MAX_UPLOAD, files: 1 },
  fileFilter: (req, file, cb) =>
    path.extname(file.originalname).toLowerCase() === ".zip"
      ? cb(null, true)
      : cb(new Error("Only .zip files are accepted."))
});

const jobs = new Map();

function publicJob(job) {
  return {
    id: job.id,
    state: job.state,
    filename: job.jarName || null,
    size: job.jarSize || null,
    buildTimeMs: job.buildTimeMs || null,
    project: job.project || null,
    steps: job.steps,
    logs: job.logs.slice(-300),
    error: job.error || null
  };
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, maxUploadBytes: MAX_UPLOAD });
});

app.post("/api/build", upload.single("project"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "ZIP file is required." });

  const id = crypto.randomBytes(16).toString("hex");
  const jobDir = path.join(BUILDS, id);
  const uploadPath = req.file.path;
  const job = {
    id, state: "queued", steps: [
      { key: "upload", label: "Uploading project", state: "done" },
      { key: "extract", label: "Extracting ZIP", state: "pending" },
      { key: "detect", label: "Detecting build system", state: "pending" },
      { key: "deps", label: "Resolving dependencies", state: "pending" },
      { key: "compile", label: "Compiling source", state: "pending" },
      { key: "jar", label: "Creating JAR", state: "pending" },
      { key: "verify", label: "Verifying JAR", state: "pending" }
    ],
    logs: [],
    startedAt: Date.now()
  };
  jobs.set(id, job);
  res.status(202).json({ id });

  setImmediate(async () => {
    try {
      await fsp.mkdir(jobDir, { recursive: true });
      job.state = "building";

      job.steps[1].state = "active";
      job.logs.push("Extracting project safely...");
      const projectRoot = await extractZipSafely(uploadPath, jobDir, MAX_EXTRACTED);
      job.steps[1].state = "done";

      job.steps[2].state = "active";
      job.logs.push("Detecting project...");
      job.project = await detectProject(projectRoot);
      if (!job.project) throw new Error("No supported Gradle or Maven build configuration was found. A source-only ZIP needs a valid build.gradle/build.gradle.kts or pom.xml.");
      job.logs.push(`${job.project.type === "gradle" ? "Gradle" : "Maven"} project detected`);
      if (job.project.wrapper) job.logs.push("Using Gradle Wrapper");
      if (job.project.minecraft?.loader) job.logs.push(`Minecraft loader: ${job.project.minecraft.loader}`);
      if (job.project.minecraft?.version) job.logs.push(`Minecraft version: ${job.project.minecraft.version}`);
      job.steps[2].state = "done";

      for (let i = 3; i <= 5; i++) job.steps[i].state = "active";
      const result = await runBuild({
        projectRoot,
        project: job.project,
        timeoutMs: BUILD_TIMEOUT,
        onLog: line => job.logs.push(line),
        onPhase: phase => {
          const map = { deps: 3, compile: 4, jar: 5 };
          if (map[phase] !== undefined) {
            for (const s of job.steps.slice(3, map[phase])) if (s.state === "active") s.state = "done";
            job.steps[map[phase]].state = "active";
          }
        }
      });

      for (const s of job.steps.slice(3, 6)) s.state = "done";
      job.steps[6].state = "active";
      job.logs.push("Verifying generated JAR...");
      if (!result.jarPath) throw new Error("Build exited successfully, but no valid output JAR was found.");
      const stat = await fsp.stat(result.jarPath);
      job.jarName = safeJarName(path.basename(result.jarPath));
      job.jarSize = stat.size;
      job.buildTimeMs = Date.now() - job.startedAt;
      await fsp.copyFile(result.jarPath, path.join(jobDir, job.jarName));
      job.steps[6].state = "done";
      job.state = "success";
      job.logs.push(`Verified JAR: ${job.jarName} (${stat.size} bytes)`);
    } catch (err) {
      job.state = "failed";
      job.error = err.publicMessage || err.message || "Build failed.";
      job.logs.push(`ERROR: ${job.error}`);
    } finally {
      try { await fsp.unlink(uploadPath); } catch {}
      // Keep successful JAR and metadata; remove all other build material.
      try {
        const entries = await fsp.readdir(jobDir);
        for (const name of entries) {
          if (name !== job.jarName) await fsp.rm(path.join(jobDir, name), { recursive: true, force: true });
        }
      } catch {}
      // Failed jobs are retained briefly so their error/logs can be viewed.
      setTimeout(async () => {
        jobs.delete(id);
        await cleanupDir(jobDir);
      }, Number(process.env.JOB_RETENTION_MS || 30 * 60 * 1000)).unref();
    }
  });
});

app.get("/api/build/:id", (req, res) => {
  if (!isValidBuildId(req.params.id)) return res.status(400).json({ error: "Invalid build ID." });
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Build not found or expired." });
  res.json(publicJob(job));
});

app.get("/api/build/:id/download", async (req, res) => {
  if (!isValidBuildId(req.params.id)) return res.status(400).send("Invalid build ID.");
  const job = jobs.get(req.params.id);
  if (!job || job.state !== "success" || !job.jarName) return res.status(404).send("JAR not available.");
  const file = path.join(BUILDS, req.params.id, job.jarName);
  if (!fs.existsSync(file)) return res.status(404).send("JAR expired.");
  res.download(file, job.jarName, { dotfiles: "deny" });
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: err.code === "LIMIT_FILE_SIZE" ? "ZIP exceeds the configured upload limit." : err.message });
  }
  if (err) return res.status(400).json({ error: err.message || "Request failed." });
  next();
});

app.listen(PORT, () => console.log(`ZIP TO JAR COMPILER listening on port ${PORT}`));