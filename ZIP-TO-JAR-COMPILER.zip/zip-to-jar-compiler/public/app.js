const $=s=>document.querySelector(s);
const file=$('#file'), drop=$('#drop'), info=$('#fileInfo'), buildBtn=$('#buildBtn'), panel=$('#panel'), steps=$('#steps'), log=$('#log'), result=$('#result'), status=$('#status'), badge=$('#badge'), projectInfo=$('#projectInfo');
let selected=null, timer=null, cleared=false;

fetch('/api/health').then(r=>r.json()).then(x=>$('#limit').textContent=formatBytes(x.maxUploadBytes)).catch(()=>$('#limit').textContent='server default');

file.addEventListener('change',()=>select(file.files[0]));
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.add('drag')}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.remove('drag')}));
drop.addEventListener('drop',ev=>select(ev.dataTransfer.files[0]));

function select(f){
 if(!f)return;
 if(!f.name.toLowerCase().endsWith('.zip'))return alert('Only .zip files are allowed.');
 selected=f; buildBtn.disabled=false;
 info.classList.remove('hidden'); info.innerHTML=`<b>${esc(f.name)}</b><br><span class="muted">${formatBytes(f.size)} • Ready to Build</span>`;
}
buildBtn.addEventListener('click',startBuild);
$('#clearLog').onclick=()=>{cleared=true;log.textContent=''};

async function startBuild(){
 if(!selected)return;
 buildBtn.disabled=true; panel.classList.remove('hidden'); result.className='result hidden'; result.innerHTML=''; log.textContent=''; cleared=false;
 status.textContent='BUILDING PROJECT...'; badge.textContent='BUILD'; badge.style.color=''; projectInfo.textContent='';
 const fd=new FormData(); fd.append('project',selected);
 try{
  const r=await fetch('/api/build',{method:'POST',body:fd}); const data=await r.json();
  if(!r.ok)throw new Error(data.error||'Upload failed.');
  timer=setInterval(()=>poll(data.id),700); await poll(data.id);
 }catch(e){showClientError(e.message)}
}
async function poll(id){
 const r=await fetch('/api/build/'+encodeURIComponent(id)); const j=await r.json();
 if(!r.ok){showClientError(j.error);return}
 render(j);
 if(j.state==='success'||j.state==='failed'){clearInterval(timer);buildBtn.disabled=false}
}
function render(j){
 steps.innerHTML=j.steps.map(s=>`<div class="step ${s.state}"><span class="dot">${s.state==='done'?'✓':s.state==='active'?'…':''}</span>${esc(s.label)}</div>`).join('');
 if(!cleared)log.textContent=j.logs.join('\\n')+'\\n';
 log.scrollTop=log.scrollHeight;
 if(j.project){projectInfo.textContent=[j.project.type?.toUpperCase(),j.project.wrapper?'Gradle Wrapper':null,j.project.minecraft?.loader,j.project.minecraft?.version].filter(Boolean).join(' • ')}
 if(j.state==='success'){
  status.textContent='✅ BUILD SUCCESSFUL'; badge.textContent='SUCCESS'; badge.style.color='#9ee6bb';
  result.className='result success'; result.innerHTML=`<b>JAR:</b> ${esc(j.filename)}<br><span class="muted">Size: ${formatBytes(j.size)} • Build time: ${formatTime(j.buildTimeMs)}</span><a class="download" href="/api/build/${encodeURIComponent(j.id)}/download">⬇ DOWNLOAD JAR</a>`;
 }else if(j.state==='failed'){
  status.textContent='❌ BUILD FAILED'; badge.textContent='FAILED'; badge.style.color='#ff9ca8';
  result.className='result failure'; result.innerHTML=`<b>Build error</b><p>${esc(j.error||'The build failed. See the compiler output above.')}</p>`;
 }else status.textContent='BUILDING PROJECT...';
}
function showClientError(msg){panel.classList.remove('hidden');status.textContent='❌ BUILD FAILED';result.className='result failure';result.innerHTML=esc(msg);buildBtn.disabled=false}
function formatBytes(n){if(!n)return'0 B';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return n.toFixed(i?1:0)+' '+u[i]}
function formatTime(ms){if(!ms)return'—';return (ms/1000).toFixed(1)+'s'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}